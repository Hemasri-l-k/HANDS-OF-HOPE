package com.project.project.fooddonor;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.SaveCallback;
import com.project.project.R;
import com.project.project.Utils;
import com.project.project.fooddonor.data.DonorPost;
import com.project.project.kisanmitra.OLXPost;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class DonorPostViewActivity extends AppCompatActivity {


    private final String TAG = "MainActivity";

    @BindView(R.id.listview)
    ListView listView;

    @BindView(R.id.viewcart)
    Button btnViewCart;

    @BindView(R.id.offers)
    Button btnOffers;

    @BindView(R.id.buyitems)
    Button btnBuyItems;

    private Unbinder unbinderknife;

    static String name = "";

    private int CAMERA_REQUEST = 100;

    String filePath = "";

    boolean isUpdate;

    Map<String, List<String>> map = new HashMap<>();

    List<String> malls = new ArrayList<>();


    int totalAmount = 0;

    String type = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kisan_items_list);

        unbinderknife = ButterKnife.bind(this);

        type = getIntent().getStringExtra("type");
        btnOffers.setVisibility(View.GONE);
        btnViewCart.setVisibility(View.GONE);
        btnBuyItems.setVisibility(View.GONE);

        fetchData();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        unbinderknife.unbind();

    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {

        }
    }

    List<ParseObject> parseObjectList = new ArrayList<>();

    public void fetchData() {

        Utils.showToast(getApplicationContext(), "Please Wait....");

        ParseQuery<ParseObject> query = ParseQuery.getQuery(DonorPost.class.getSimpleName());
        query.whereEqualTo(DonorPost.assigned, false);

        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {

                if (e == null) {

                    if (objects.size() > 0) {
                        parseObjectList = objects;
                        filterByExpiry();
                        if(fileteredParseObjects.size() > 0){
                            Utils.showToast(DonorPostViewActivity.this, "Items available");
                        }else{
                            Utils.showToast(DonorPostViewActivity.this, "Items not available");
                        }

                        CustomAdapter ca = new CustomAdapter(DonorPostViewActivity.this, fileteredParseObjects);
                        listView.setAdapter(ca);
                    } else {
                        Utils.showToast(getApplicationContext(), "No items available");
                    }
                } else {
                    e.printStackTrace();
                    Utils.showToast(getApplicationContext(), "fetch error: " + e.getMessage());
                }
            }
        });
    }
    List<ParseObject> fileteredParseObjects = new ArrayList<>();
    private void filterByExpiry(){
        for(ParseObject po : parseObjectList){
            Date date = po.getCreatedAt();
            long createdTimeInMillis = date.getTime();
            String expiry = po.getString(DonorPost.expiry);
            if(expiry != null && !(expiry.equals(""))){
                int expiryInmillis =  Integer.parseInt(expiry) * 60 * 1000;

                long timeLapsed = System.currentTimeMillis() - createdTimeInMillis;
                if(timeLapsed <= expiryInmillis){
                    fileteredParseObjects.add(po);
                }
            }else{
                fileteredParseObjects.add(po);
            }
        }
    }

    public class CustomAdapter extends BaseAdapter {

        List<ParseObject> itemsList;

        Context mContext;

        ViewHolder viewHolder;

        public CustomAdapter(Context mContext, List<ParseObject> itemslist) {
            this.mContext = mContext;
            this.itemsList = itemslist;
        }

        @Override
        public int getCount() {
            return itemsList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final View result;

            if (convertView == null) {

                viewHolder = new ViewHolder();
                LayoutInflater inflater = LayoutInflater.from(mContext);
                convertView = inflater.inflate(R.layout.items_list_rows, parent, false);

                viewHolder.imageView = (ImageView) convertView.findViewById(R.id.imageview);
                viewHolder.textView = (TextView) convertView.findViewById(R.id.textview);
                viewHolder.tvQuantity = (TextView) convertView.findViewById(R.id.quantity);
                viewHolder.btnAccept = (Button) convertView.findViewById(R.id.accept);
                viewHolder.btnOpenMaps = (Button) convertView.findViewById(R.id.btnMaps);
                viewHolder.btnDunzo = (Button) convertView.findViewById(R.id.btnDunzo);
                result = convertView;
                convertView.setTag(viewHolder);

            } else {
                viewHolder = (ViewHolder) convertView.getTag();
                result = convertView;
            }

            final ParseObject item = itemsList.get(position);

            if(item.getBoolean(DonorPost.assigned)){
                viewHolder.btnAccept.setEnabled(false);
            }
            viewHolder.textView.setText(
                    "Type: " + item.getString(DonorPost.type)+
                    "" + item.getString(DonorPost.name)
                            + "\nQuantity: " + item.getString(DonorPost.quantity) + "\nDesc:  " +
                    item.getString(DonorPost.description) + "\nPhone: " + item.getString(DonorPost.phone) + "\nBy: " + item.getString(DonorPost.contactName)
            );

            if (item.getString(OLXPost.image) != null) {
                Picasso.with(mContext).load(item.getString(OLXPost.image)).into(viewHolder.imageView);
            }

            viewHolder.btnOpenMaps.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Utils.openMaps(item.getString(DonorPost.location), mContext);
                }
            });

            viewHolder.btnDunzo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showAlertDialog();
                }
            });

            viewHolder.btnAccept.setVisibility(View.VISIBLE);

            viewHolder.btnAccept.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    item.put(DonorPost.assigned, true);
                    String phone = item.getString(DonorPost.phone);
                    if(phone!=null){
                        Utils.sendSMS(phone, "Dear Donor, thanks for donating and the receiver has been accepted your donation!");
                    }else{
                        Utils.showToast(getApplicationContext(), "Phone number not updated");
                    }
                    item.saveInBackground(new SaveCallback() {
                        @Override
                        public void done(ParseException e) {
                            if(e == null){
                                Utils.showToast(getApplicationContext(), "Donate accepted");
                                notifyDataSetChanged();
                            }else{
                                Utils.showToast(getApplicationContext(), "Donate error: "+e.getMessage());
                            }
                        }
                    });
                }
            });

            return result;
        }

        public class ViewHolder {
            TextView textView;
            ImageView imageView;
            Button btnAccept;

            Button btnOpenMaps;

            Button btnDunzo;
            TextView tvQuantity;
        }
    }


    public void showAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(DonorPostViewActivity.this);

        builder.setTitle("Warning");

        builder.setMessage("Dunzo Amount should be bear by the receiver");


        //Button One : Yes
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                Utils.launchExternalApp("com.dunzo.user", DonorPostViewActivity.this);
            }
        });


        //Button Two : No
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog diag = builder.create();
        diag.show();
    }
}
