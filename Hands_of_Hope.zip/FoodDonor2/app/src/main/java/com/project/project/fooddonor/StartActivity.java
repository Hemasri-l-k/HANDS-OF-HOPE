package com.project.project.fooddonor;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.project.project.R;
import com.project.project.acommon.LoginActivity;

import butterknife.Unbinder;

public class StartActivity extends AppCompatActivity {

    String TAG = "SplashActivity";
    private Unbinder unbinderknife;

    public static String name = "", username, password, phone, address;

    public static Class sClass = com.project.project.droneredzone.HomeActivity.class;


    Button btnContinue;
    ImageView ivStart, ivAbout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.fooddonor_start_activity);

        ivStart = findViewById(R.id.btnStart);
        ivAbout = findViewById(R.id.btnAbout);


        ivStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                Intent intent = new Intent(StartActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        ivAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StartActivity.this, AboutActivity.class);
                startActivity(intent);
            }
        });

    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }

}
