package com.project.project.fooddonor;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.project.project.R;
import com.project.project.Utils;
import com.project.project.acommon.data.Users;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class NGOActivity extends AppCompatActivity {


    private final String TAG = this.getClass().getSimpleName();


    @BindView(R.id.listview)
    ListView lvListView;

    private Unbinder unbinderknife;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.common_listview);

        unbinderknife = ButterKnife.bind(this);


        if(getIntent().getBooleanExtra("donor", false)){
            fetchData();
        }else{

            dataList.add("Shivashakthi Mahila Sangha\n" +
                    "Phone – 09980133164");
            dataList.add("Priyadarshi Mahila Janapara Sanghatane\n" +
                    "Phone - 07041754008");
            dataList.add("Punarjanma Ashraya Dhama\n" +
                    "Phone - 09980917606");
            dataList.add("Snehashraya Foundation\n" +
                    "Phone – 09980556259");
            dataList.add("Sanjeevini Trust For The Disabled\n" +
                    "Phone - 06366982981");
            dataList.add("Vidyaranya-08022862622");

            ArrayAdapter<String> aa = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataList);
            lvListView.setAdapter(aa);
        }


        lvListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        unbinderknife.unbind();

    }


    public void fetchData() {

        Utils.showToast(getApplicationContext(), "Please Wait....");

        ParseQuery<ParseObject> query = ParseQuery.getQuery(Users.class.getSimpleName());
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {

                if (e == null) {

                    if (objects.size() > 0) {

                        updateList(objects);
                    } else {
                        Utils.showToast(getApplicationContext(), "No data found");
                    }

                } else {
                    e.printStackTrace();
                    Utils.showToast(getApplicationContext(), "fetch error: " + e.getMessage());
                }
            }
        });
    }

    List<String> dataList = new ArrayList<>();

    public void updateList(List<ParseObject> poList) {
        for (ParseObject po : poList) {
            String data = po.getString(Users.name)
                    + "\n" + po.getString(Users.phone);
            dataList.add(data);
        }

        ArrayAdapter<String> aa = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataList);
        lvListView.setAdapter(aa);
    }

}
