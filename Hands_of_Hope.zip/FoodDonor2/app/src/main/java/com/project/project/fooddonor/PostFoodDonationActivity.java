package com.project.project.fooddonor;

import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseObject;
import com.parse.SaveCallback;
import com.project.project.R;
import com.project.project.Utils;
import com.project.project.acommon.LocationHandler;
import com.project.project.acommon.LoginActivity;
import com.project.project.fooddonor.data.DonorPost;
import com.project.project.kisanmitra.OLXPost;
import com.project.project.kisanmitra.OneShotPreviewActivity;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class PostFoodDonationActivity extends AppCompatActivity {

    @BindView(R.id.editText)
    EditText etTitle;

    @BindView(R.id.editText2)
    EditText etQuantity;

    @BindView(R.id.editText3)
    EditText etDesctiption;

    @BindView(R.id.editText4)
    EditText etLocation;

    @BindView(R.id.editText5)
    EditText etContactName;

    @BindView(R.id.editText6)
    EditText etExpiryMinutes;

    @BindView(R.id.submit)
    TextView btnSubmit;

    @BindView(R.id.btnclick)
    Button btnClick;

    @BindView(R.id.imageview)
    ImageView ivImageView;

    @BindView(R.id.spinner)
    Spinner spinnerUserType;

    String[] donationTypes = {"Food", "Books", "Clothes", "Other Essentials"};

    private Unbinder unbinderknife;
    private String TAG = "RegisterActivity";
    private File file;

    String type = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.post_fooddonar_activity);

        unbinderknife = ButterKnife.bind(this);

        ivImageView.setImageResource(android.R.drawable.ic_menu_upload);



        new LocationHandler(this).initLocation(new LocationHandler.OnLocationChanged() {
            @Override
            public void onLocationAvailable(Location location) {
                etLocation.setText(location.getLatitude()+","+location.getLongitude());
            }
        });

        ArrayAdapter<String> aa1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, donationTypes);
        aa1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerUserType.setAdapter(aa1);


        spinnerUserType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedType = donationTypes[i].toLowerCase();
                if(selectedType.equals("food")){
                    etExpiryMinutes.setVisibility(View.VISIBLE);
                }else{
                    etExpiryMinutes.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        ivImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                launchCamera(100);
                Intent intent = new Intent(PostFoodDonationActivity.this, OneShotPreviewActivity.class);
                startActivity(intent);
            }
        });


        btnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Utils.showToast(getApplicationContext(), "button clikc");

                String name = etTitle.getText().toString();
                String amount = etDesctiption.getText().toString();
                String quantity = etQuantity.getText().toString();
                String contactName = etContactName.getText().toString();
                String location = etLocation.getText().toString();
                String expiryMinutes = etExpiryMinutes.getText().toString();

                if (name.equals("")) {
                    Utils.showToast(getApplicationContext(), "Enter name");
                } else if (quantity.equals("")) {
                    Utils.showToast(getApplicationContext(), "Enter quantity");
                } else if (amount.equals("")) {
                    Utils.showToast(getApplicationContext(), "Enter amount");
                } else if (OneShotPreviewActivity.fileURL.equals("")) {
                    Utils.showToast(getApplicationContext(), "Capture image");
                } else if (contactName.equals("")) {
                    Utils.showToast(getApplicationContext(), "Enter name");
                } else if (location.equals("")) {
                    Utils.showToast(getApplicationContext(), "Waiting. For location");
                } else {
                    saveData(name, quantity, amount, OneShotPreviewActivity.fileURL, location, expiryMinutes);
                }
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.showToast(getApplicationContext(), "Submit clicked");
                Log.i(TAG, "Submit clicked");
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unbinderknife.unbind();
    }


    private static File getOutputMediaFilepath() {
        File mediaStorageDir = new File("/sdcard/cameraface/");

        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                return null;
            }
        }
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File file = new File(mediaStorageDir.getPath() + File.separator +
                "IMG_" + timeStamp + ".jpg");
        try {
            file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return file;
    }

    public void launchCamera(int requestcode) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        file = getOutputMediaFilepath();
        Log.i(TAG, "File path: " + file.getAbsolutePath());
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            file = getOutputMediaFilepath();
            intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(file));
        } else {
            file = getOutputMediaFilepath();
            Uri photoUri = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", file);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (intent.resolveActivity(getApplicationContext().getPackageManager()) != null) {
            startActivityForResult(intent, requestcode);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!OneShotPreviewActivity.filePath.equals("")) {
            ivImageView.setImageURI(Uri.fromFile(new File(OneShotPreviewActivity.filePath)));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 100) {
            if (resultCode == RESULT_OK) {


            }
        }
    }

    public void saveFile(String name, String quantity, String amount) {

        Log.i(TAG, "Saving file");
        ParseFile parseFile = new ParseFile(file);
        parseFile.saveInBackground(new SaveCallback() {
            @Override
            public void done(ParseException e) {
                if (e == null) {
                    Log.i(TAG, "Parse upload success: " + parseFile.getUrl());

                    ParseObject parseObject = new ParseObject(OLXPost.class.getSimpleName());
                    parseObject.put(OLXPost.name, name);
                    parseObject.put(OLXPost.quantity, quantity);
                    parseObject.put(OLXPost.price, amount);
                    parseObject.put(OLXPost.image, parseFile.getUrl());
                    parseObject.put(OLXPost.username, LoginActivity.username);
                    parseObject.put(OLXPost.phone, LoginActivity.phone);

                    parseObject.saveInBackground(new SaveCallback() {
                        @Override
                        public void done(ParseException e) {
                            if (e == null) {
                                Utils.showToast(getApplicationContext(), "Your post added successfully");
                                finish();
                            } else {
                                Utils.showToast(getApplicationContext(), "Your post added error: " + e.getMessage());
                                finish();
                            }
                        }
                    });

                } else {
                    e.printStackTrace();
                }
            }
        });
    }

    String selectedType = "";
    public void saveData(String name, String quantity, String amount, String url, String priceperHour, String expiryInminutes) {
        ParseObject parseObject = new ParseObject(DonorPost.class.getSimpleName());
        parseObject.put(DonorPost.name, name);
        parseObject.put(DonorPost.quantity, quantity);
        parseObject.put(DonorPost.description, amount);
        parseObject.put(DonorPost.image, url);
        parseObject.put(DonorPost.contactName, etContactName.getText().toString());
        parseObject.put(DonorPost.location, etLocation.getText().toString());
        parseObject.put(DonorPost.username, LoginActivity.username);
        parseObject.put(DonorPost.phone, LoginActivity.phone);
        parseObject.put(DonorPost.assigned, false);
        parseObject.put(DonorPost.type, selectedType);
        parseObject.put(DonorPost.expiry, expiryInminutes);

        parseObject.saveInBackground(new SaveCallback() {
            @Override
            public void done(ParseException e) {
                if (e == null) {
                    Utils.showToast(getApplicationContext(), "Your post added successfully");
                    finish();
                } else {
                    Utils.showToast(getApplicationContext(), "Your post added error: " + e.getMessage());
                    finish();
                }
            }
        });

    }
}
