package com.project.project.fooddonor.data;

public class DonorPost {

    public static String name = "name";

    public static String quantity = "quantity";

    public static String description = "description";

    public static String image = "image";

    public static String username = "username";

    public static String phone = "phone";
    public static String contactName = "contactName";

    public static String location = "location";

    public static String type = "type";

    public static String assigned = "assigned";

    public static String expiry = "expiry";
}
