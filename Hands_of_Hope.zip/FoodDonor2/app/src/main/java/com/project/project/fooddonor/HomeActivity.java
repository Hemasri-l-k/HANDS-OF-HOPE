package com.project.project.fooddonor;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.project.project.R;
import com.project.project.acommon.LoginActivity;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class HomeActivity extends AppCompatActivity {


    private final String TAG = this.getClass().getSimpleName();

    @BindView(R.id.button1)
    Button btnDonor;

    @BindView(R.id.button3)
    Button btnAcceptor;

    @BindView(R.id.button4)
    Button btnDonorList;

    @BindView(R.id.button2)
    Button btnNgos;

    @BindView(R.id.button5)
    Button btnLogout;

    @BindView(R.id.donor1)
    LinearLayout llDonor1;

    @BindView(R.id.donor2)
    LinearLayout llDonor2;

    @BindView(R.id.receiver1)
    LinearLayout llReceiver1;

    @BindView(R.id.receiver2)
    LinearLayout llReceiver2;

    @BindView(R.id.mainlayout)
    LinearLayout llMainLayout;

    private Unbinder unbinderknife;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.fooddonor_home);

        unbinderknife = ButterKnife.bind(this);


        if (LoginActivity.type.equalsIgnoreCase("donor")) {
            llDonor1.setVisibility(View.VISIBLE);
            llDonor2.setVisibility(View.VISIBLE);
            llReceiver1.setVisibility(View.GONE);
            llReceiver2.setVisibility(View.GONE);
            llMainLayout.setBackgroundResource(R.drawable.handsofhopepink);
        } else {
            llDonor1.setVisibility(View.GONE);
            llDonor2.setVisibility(View.GONE);
            llReceiver1.setVisibility(View.VISIBLE);
            llReceiver2.setVisibility(View.VISIBLE);
            llMainLayout.setBackgroundResource(R.drawable.handsofhopeblue);
        }
        btnDonor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, PostFoodDonationActivity.class);
                startActivity(intent);
            }
        });

        btnAcceptor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, DonorPostViewActivity.class);
                startActivity(intent);
            }
        });


        btnNgos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, ListViewActivity.class);
                intent.putExtra("donor", false);
                startActivity(intent);
            }
        });

        btnDonorList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, ListViewActivity.class);
                intent.putExtra("donor", true);
                startActivity(intent);
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog();
            }
        });
    }

    public void alertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.app_name));
        builder.setMessage("Do you want to logout from app?");

        //Button One : Yes
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                finish();

            }
        });


        //Button Two : No
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        AlertDialog diag = builder.create();
        diag.show();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        unbinderknife.unbind();

    }

}
