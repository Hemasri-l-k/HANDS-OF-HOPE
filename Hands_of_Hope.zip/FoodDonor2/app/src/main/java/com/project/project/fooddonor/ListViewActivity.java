package com.project.project.fooddonor;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.project.project.R;
import com.project.project.Utils;
import com.project.project.acommon.data.Users;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class ListViewActivity extends AppCompatActivity {


    private final String TAG = this.getClass().getSimpleName();


    @BindView(R.id.listview)
    ListView lvListView;

    @BindView(R.id.mainlayout)
    LinearLayout lvMainLayout;

    private Unbinder unbinderknife;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.common_listview);

        unbinderknife = ButterKnife.bind(this);


        if(getIntent().getBooleanExtra("donor", false)){
            lvMainLayout.setBackgroundResource(R.drawable.handsofhopeblue);
            fetchData();
        }else{
            lvMainLayout.setBackgroundResource(R.drawable.handsofhopepink);
            dataList.add("Sri Chowdappa Geetha Ashrama\n" +
                    "Phone – 09980133164\nloc: 12.9575213,77.53917");
            dataList.add("Orphanage Children & Handicap Centre\n" +
                    "Phone - 07041754008\nloc: 12.9379105,77.5385491");
            dataList.add("Socare Ind\n" +
                    "Phone - 09980917606\nloc: 12.9886386,77.5344135");
            dataList.add("Saraswathi Educational & Charitable Trust\n" +
                    "Phone – 09980556259\nloc: 12.9780514,77.499981");
            dataList.add("Aasare Foundation Trust Orphanage\n" +
                    "Phone - 06366982981\nloc: 13.0154352,77.5193492");

            ArrayAdapter<String> aa = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataList);
            lvListView.setAdapter(aa);
        }


        lvListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(!getIntent().getBooleanExtra("donor", false)){
                    String[] temp = dataList.get(position).split("\n");
                    String[] loc = temp[2].split(" ");
                    Utils.openMaps(loc[1], ListViewActivity.this);
                }
            }
        });
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        unbinderknife.unbind();

    }


    public void fetchData() {

        Utils.showToast(getApplicationContext(), "Please Wait....");

        ParseQuery<ParseObject> query = ParseQuery.getQuery(Users.class.getSimpleName());
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {

                if (e == null) {

                    if (objects.size() > 0) {

                        updateList(objects);
                    } else {
                        Utils.showToast(getApplicationContext(), "No data found");
                    }

                } else {
                    e.printStackTrace();
                    Utils.showToast(getApplicationContext(), "fetch error: " + e.getMessage());
                }
            }
        });
    }

    List<String> dataList = new ArrayList<>();

    public void updateList(List<ParseObject> poList) {
        for (ParseObject po : poList) {
            String data = po.getString(Users.name)
                    + "\n" + po.getString(Users.phone);
            dataList.add(data);
        }

        ArrayAdapter<String> aa = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataList);
        lvListView.setAdapter(aa);
    }

}
