package com.project.project.acommon.data;

public class Users {

    public static String objectId = "objectId";

    public static String username = "username";

    public static String password = "password";

    public static String name = "name";

    public static String stopName = "stopName";

    public static String qualification = "qualification";

    public static String address = "address";

    public static String phone = "phone";

    public static String guardianPhone = "guardianPhone";

    public static String boardStatus = "boardStatus";

    public static String busNo = "busNo";

    public static String locality = "locality";

    public static String dob = "dob";

    public static String type = "type";

    public static String amount = "amount";

    public static String medicalHistory = "medicalHistory";

    public static String bloodGroup = "bloodGroup";

    public static String isSelected = "isSelected";

}
