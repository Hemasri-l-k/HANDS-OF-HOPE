package com.project.project.fooddonor;

import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.project.project.R;

import butterknife.Unbinder;

public class AboutActivity extends AppCompatActivity {

    String TAG = "SplashActivity";
    private Unbinder unbinderknife;

    public static String name = "", username, password, phone, address;

    public static Class sClass = com.project.project.droneredzone.HomeActivity.class;


    Button btnContinue;
    ImageView ivStart, ivAbout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.fooddonor_about_activity);

    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }

}
